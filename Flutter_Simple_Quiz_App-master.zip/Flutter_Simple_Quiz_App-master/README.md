# flutter_simple_quiz_app

A new Flutter project.

UI Screenshots:

![smartmockups_l4k0wi54](https://user-images.githubusercontent.com/60041910/174446035-7ba4907b-ed3a-46d2-a1c2-1b332214476e.jpg)


![smartmockups_l4k0vg1s](https://user-images.githubusercontent.com/60041910/174446036-646902b0-64ef-4659-9589-9170ff35ec88.jpg)
